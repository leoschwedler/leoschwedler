<div align="center">

<img src="./assets/hacker-header.gif" width="100%" alt="Animated hacker style Leo header">

<img src="./assets/code-scroll.gif" width="100%" alt="Animated scrolling code">

<br>

<img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&weight=700&size=17&duration=2200&pause=700&color=22C55E&center=true&vCenter=true&width=700&lines=%3E+ACCESS+GRANTED;%3E+SOFTWARE+DEVELOPER;%3E+MOBILE+%7C+FRONTEND+%7C+BACKEND" alt="Terminal animation">

</div>

---

<div align="center">

### `ABOUT`

**Software Developer** with experience in **Mobile, Frontend and Backend development**.

I build applications and APIs focused on **clean code, maintainability and practical architecture**.

</div>

<br>

<div align="center">

<img src="https://skillicons.dev/icons?i=kotlin,android,flutter,java,spring,react,ts,js,html,css,postgres,mysql,docker,git,github&perline=8" alt="Technology stack">

</div>

<img src="./assets/code-scroll.gif" width="100%" alt="Animated code divider">

### `STACK`

```text
MOBILE      Kotlin • Android • Jetpack Compose • Flutter
FRONTEND    React • TypeScript • JavaScript • HTML • CSS
BACKEND     Java • Spring Boot • REST APIs
DATABASE    PostgreSQL • MySQL
ARCHITECT.  Clean Architecture • SOLID • MVVM • MVI
TOOLS       Docker • Git • GitHub • IntelliJ • VS Code
```

<img src="./assets/code-scroll.gif" width="100%" alt="Animated code divider">

<div align="center">

### `GITHUB`

<img src="https://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=leoschwedler&theme=github_dark" width="100%" alt="GitHub profile details">

<br><br>

<img src="https://github-profile-summary-cards.vercel.app/api/cards/stats?username=leoschwedler&theme=github_dark" width="49%" alt="GitHub stats">
<img src="https://github-profile-summary-cards.vercel.app/api/cards/repos-per-language?username=leoschwedler&theme=github_dark" width="49%" alt="Languages">

</div>

<img src="./assets/code-scroll.gif" width="100%" alt="Animated code divider">

<div align="center">

### `CONNECT`

<a href="https://github.com/leoschwedler">
<img src="https://img.shields.io/badge/GITHUB-000000?style=for-the-badge&logo=github&logoColor=22C55E" alt="GitHub">
</a>
<a href="https://www.linkedin.com/in/leonardo-schwuedller/">
<img src="https://img.shields.io/badge/LINKEDIN-000000?style=for-the-badge&logo=linkedin&logoColor=22C55E" alt="LinkedIn">
</a>
<a href="https://www.instagram.com/developer_ls/">
<img src="https://img.shields.io/badge/INSTAGRAM-000000?style=for-the-badge&logo=instagram&logoColor=22C55E" alt="Instagram">
</a>

<br><br>

<img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&size=14&duration=2000&pause=700&color=22C55E&center=true&vCenter=true&width=620&lines=%3E+THANKS+FOR+VISITING;%3E+CONNECTION+CLOSED...;%3E+SEE+YOU+IN+THE+NEXT+COMMIT." alt="Closing terminal animation">

</div>
